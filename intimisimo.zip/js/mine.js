'use strict'

var confirmacion = confirm("Este es un sitio solo para mayores de edad");

if (confirmacion == true){

}else{
	window.open('https://sesamo.com/', '_blank');
}